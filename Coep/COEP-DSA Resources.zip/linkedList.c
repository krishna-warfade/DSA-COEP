#include<stdio.h>
#include<stdlib.h>
struct list
{
	int data;
	struct list *next;
}node;

struct list *temp=NULL;
struct list *head=NULL;

void insertatbegin(int data1)
{
	struct list *newnode=(struct list*)	malloc(sizeof(struct list));
	newnode->data=data1;
	if(head==NULL)
	{
		newnode->next=NULL;
		head=newnode;
		printf("\n %d is inserted at the beginning ",newnode->data);
	}
	else
	{
		temp=head;
		newnode->next=temp;
		head=newnode;
		printf("\n %d is inserted at the beginning ",newnode->data);
	}
}

void traverse()
{
	if(head==NULL)
	{
		printf("\nList is empty");
		return;
	}
	else
	{
		temp=head;
		printf("\n Linked List Elements are : :");
		while(temp->next!=NULL)
		{
			printf("%d\t",temp->data);
			temp=temp->next;
		}
		printf("%d \n",temp->data);
	}
}

void insertatend(int data1)
{
	struct list *newnode=(struct list*)	malloc(sizeof(struct list));
	newnode->data=data1;
	newnode->next=NULL;
	if(head==NULL)
	{
		head=newnode;
	}
	else
	{
		temp=head;
		while(temp->next!=NULL)
		{
			temp=temp->next;
		}
		temp->next=newnode;
		printf("\n %d is inserted at the end",newnode->data);
	}
}
void deleteatspecific()
{
	int num;
	printf("Which element you would like to delete?::");
	scanf("%d",&num);
	if(head==NULL)
	{
		printf("Underflow condition");
		return;
	}
	else
	{
		struct list *prev=(struct list*)malloc(sizeof(struct list));
		struct list *ptr=(struct list*)	malloc(sizeof(struct list));
		temp=head;
		prev=temp;
		while(temp->data!=num)
		{
			prev=temp;
			temp=temp->next;
		}
		ptr=temp;
		prev->next=temp->next;
		printf("\n %d is deleted ",temp->data);
		free(temp);
	}
}

int main()
{
	traverse();
	insertatbegin(12);
	traverse();
	insertatbegin(13);
	traverse();
	insertatend(14);
	traverse();
	insertatend(15);
	traverse();
	deleteatspecific();
	traverse();
	return 0;
}
